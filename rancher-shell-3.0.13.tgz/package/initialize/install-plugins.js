import PortalVue from 'portal-vue';
import { MODAL_CONTAINER_SELECTOR, SWITCHER_POPPER_SELECTOR } from '@shell/utils/dom';
import Vue3Resize from 'vue3-resize';
import FloatingVue from 'floating-vue';
import 'vue3-resize/dist/vue3-resize.css';

// import '@shell/plugins/extend-router';
import '@shell/plugins/formatters';

import i18n from '@shell/plugins/i18n';
import globalFormatters from '@shell/plugins/global-formatters';

import axios from '@shell/utils/axios';
import config from '@shell/utils/config';
import axiosShell from '@shell/plugins/axios';
import * as intNumber from '@shell/directives/int-number';
import dashboardClientInit from '@shell/plugins/dashboard-client-init';
import plugin from '@shell/plugins/plugin';
import pluginsLoader from '@shell/core/plugins-loader.js';
import replaceAll from '@shell/plugins/replaceall';
import steveCreateWorker from '@shell/plugins/steve-create-worker';
import ShortKey from '@shell/plugins/shortkey';
import { initUiApis } from '@shell/apis/impl/apis';

import 'floating-vue/dist/style.css';
import { floatingVueOptions } from '@shell/plugins/floating-vue';

import dynamicContent from '@shell/plugins/dynamic-content';
import { initAriaAnnouncer } from '@shell/utils/aria-announce';

export async function installPlugins(vueApp) {
  // The screen reader live regions have to be in the accessibility tree before the first
  // status change, so they go in ahead of the mount. See @shell/utils/aria-announce.
  initAriaAnnouncer();

  vueApp.use(globalFormatters);
  vueApp.use(PortalVue);
  vueApp.use(Vue3Resize);
  vueApp.use(FloatingVue, floatingVueOptions);
  vueApp.use(
    ShortKey,
    {
      prevent:          ['input', 'textarea', 'select'],
      // A surface that owns the screen silences the app's shortcuts while it is up.
      preventContainer: [MODAL_CONTAINER_SELECTOR, SWITCHER_POPPER_SELECTOR]
    });
}

export async function installInjectedPlugins(app, vueApp) {
  const pluginDefinitions = [
    config,
    axios,
    initUiApis,
    pluginsLoader,
    axiosShell,
    intNumber,
    dashboardClientInit,
    replaceAll,
    plugin,
    steveCreateWorker,
    dynamicContent,
  ];

  const installations = pluginDefinitions.map(async(pluginDefinition) => {
    if (typeof pluginDefinition === 'function') {
      await pluginDefinition(
        app.context,
        (key, value) => inject(key, value, app.context, vueApp),
        vueApp
      );
    }
  });

  await Promise.all(installations);

  // We had i18n/init happening asynchronously within the i18n installation method. We need this to happen synchronously otherwise we end up with race conditions where some pages won't load when translated.
  // If there's any performance reasons this can be done concurrently with all of the installation promises above but I felt it was organizationally better to keep both i18n items together.
  await app.store.dispatch('i18n/init');

  vueApp.use(i18n, { store: app.store });
}

/**
 * Injects a key-value pair into a given context and installs a Vue plugin with
 * the provided key-value pair.
 *
 * @param {string} key The key to be injected
 * @param {*} value The value to be injected
 * @param {object} context The context object into which the key-value pair will
 * be injected
 * @param {object} vueApp The Vue instance
 * @returns {void}
 *
 * @property {object} context.app The app object within the context
 * @property {object} context.store The store object within the context
 *
 * Note: This function mutates the context object, including the context app and
 * store.
 */
function inject(key, value, context, vueApp) {
  if (!key) {
    throw new Error('inject(key, value) has no key provided');
  }
  if (value === undefined) {
    throw new Error(`inject('${ key }', value) has no value provided`);
  }

  const { app, store } = context;

  key = `$${ key }`;
  // Add into app
  app[key] = value;
  // Add into context
  if (!app.context[key]) {
    app.context[key] = value;
  }

  // Add into store
  store[key] = app[key];

  // Check if plugin not already installed
  const installKey = `__plugin_${ key }_installed__`;

  window.installedPlugins = window.installedPlugins || {};

  if (window.installedPlugins[installKey]) {
    return;
  }
  window[window.installedPlugins] = true;

  // Call vueApp.use() to install the plugin into vm
  vueApp.use(() => {
    if (!Object.prototype.hasOwnProperty.call(vueApp.config.globalProperties, key)) {
      Object.defineProperty(vueApp.config.globalProperties, key, {
        get() {
          return app.context[key];
        }
      });
    }
  });
}
