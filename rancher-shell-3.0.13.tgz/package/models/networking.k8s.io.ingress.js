import { INGRESS_CLASS, SECRET, SERVICE } from '@shell/config/types';
import { isValidUrl } from '@shell/utils/validators/setting';
import { get } from '@shell/utils/object';
import isEmpty from 'lodash/isEmpty';
import SteveModel from '@shell/plugins/steve/steve-class';
import {
  findIfExists, ingressBackends, ingressServiceNames, relatedEntry, typeForKind
} from '@shell/utils/editable-related-resources';

function tlsHosts(spec) {
  const tls = spec.tls || [];

  return tls.flatMap((tls) => tls.hosts || []);
}

function isTlsHost(spec, host) {
  return tlsHosts(spec).includes(host);
}

export function ingressFullPath(resource, rule, path = {}) {
  const spec = resource.spec;
  const hostValue = rule.host || '';
  const pathValue = path.path || '';
  let protocol = '';

  if (hostValue) {
    protocol = isTlsHost(spec, hostValue) ? 'https://' : 'http://';
  }

  return `${ protocol }${ hostValue }${ pathValue }`;
}

export default class Ingress extends SteveModel {
  get tlsHosts() {
    return tlsHosts(this.spec);
  }

  get isTlsHost() {
    return (host) => isTlsHost(this.spec, host);
  }

  targetTo(workloads, serviceName) {
    if (!serviceName) {
      return null;
    }

    const isTargetsWorkload = serviceName.startsWith('ingress-');
    const id = `${ this.namespace }/${ serviceName }`;

    if (isTargetsWorkload) {
      // Need to expose workloadId's and fetch specific ones in IngressTarget?
      const workload = workloads.find((w) => w.id === (id));

      return workload?.detailLocation || '';
    } else {
      return {
        name:   'c-cluster-product-resource-namespace-id',
        params: {
          resource:  SERVICE,
          id:        serviceName,
          namespace: this.namespace,
        }
      };
    }
  }

  createRulesForListPage(workloads, certificates) {
    const rules = this.spec.rules || [];

    return rules.flatMap((rule) => {
      const paths = rule?.http?.paths || [];

      return paths.map((path) => this.createPathForListPage(workloads, rule, path, certificates));
    });
  }

  createPathForListPage(workloads, rule, path, certificates) {
    const serviceName = get(path?.backend, this.serviceNamePath);
    const fullPath = this.fullPath(rule, path);

    return {
      // is-url thinks urls which contain '*' are valid so adding an additional check for '*'
      isUrl:           isValidUrl(fullPath) && !fullPath.includes('*'),
      pathType:        path.pathType,
      fullPath,
      serviceName,
      serviceTargetTo: this.targetTo(workloads, serviceName),
      certs:           this.certLinks(rule, certificates),
      targetLink:      this.targetLink(workloads, serviceName),
      port:            get(path?.backend, this.servicePortPath) || get(path?.backend, this.servicePortNamePath)
    };
  }

  fullPath(rule, path) {
    return ingressFullPath(this, rule, path);
  }

  certLink(cert, certificates = []) {
    const secretName = cert.secretName || this.t('ingress.rulesAndCertificates.defaultCertificate');
    let to;

    if (cert.secretName && certificates.includes(secretName)) {
      to = {
        name:   'c-cluster-product-resource-namespace-id',
        params: {
          resource: SECRET,
          id:       secretName
        }
      };
    }

    return {
      to,
      text:    secretName,
      options: { internal: true }
    };
  }

  certLinks(rule, certificates) {
    const certs = this.spec.tls || [];
    const matchingCerts = certs.filter((cert) => {
      const hosts = cert.hosts || [];

      return hosts.includes(rule.host);
    });

    return matchingCerts.map((cert) => this.certLink(cert, certificates));
  }

  targetLink(workloads, serviceName) {
    return {
      to:      this.targetTo(workloads, serviceName),
      text:    serviceName,
      options: { internal: true }
    };
  }

  createDefaultService(workloads) {
    const backend = get(this.spec, this.defaultBackendPath);
    const serviceName = get(backend, this.serviceNamePath);

    if ( !serviceName ) {
      return null;
    }

    return {
      name:     serviceName,
      targetTo: this.targetTo(workloads, serviceName)
    };
  }

  get cache() {
    if (!this.cacheObject) {
      this.cacheObject = {};
    }

    return this.cacheObject;
  }

  get showPathType() {
    if (!this.cache.showPathType) {
      this.cache.showPathType = this.$rootGetters['cluster/pathExistsInSchema'](this.type, 'spec.rules.http.paths.pathType');
    }

    return this.cache.showPathType;
  }

  get useNestedBackendField() {
    if (!this.cache.useNestedBackendField) {
      this.cache.useNestedBackendField = this.$rootGetters['cluster/pathExistsInSchema'](this.type, 'spec.rules.http.paths.backend.service.name');
    }

    return this.cache.useNestedBackendField;
  }

  get serviceNamePath() {
    const nestedPath = 'service.name';
    const flatPath = 'serviceName';

    return this.useNestedBackendField ? nestedPath : flatPath;
  }

  get servicePortPath() {
    const nestedPath = 'service.port.number';
    const flatPath = 'servicePort';

    return this.useNestedBackendField ? nestedPath : flatPath;
  }

  get servicePortNamePath() {
    const nestedPath = 'service.port.name';
    // Flat API has a single `servicePort` field for both name and number.
    const flatPath = 'servicePort';

    return this.useNestedBackendField ? nestedPath : flatPath;
  }

  get defaultBackendPath() {
    const defaultBackend = this.$rootGetters['cluster/pathExistsInSchema'](this.type, 'spec.defaultBackend');

    return defaultBackend ? 'defaultBackend' : 'backend';
  }

  get hasDefaultBackend() {
    return !isEmpty(this.spec[this.defaultBackendPath]);
  }

  get details() {
    const out = this._details;

    if (this.spec?.ingressClassName) {
      out.push({
        label:   this.t('ingress.ingressClass.label'),
        content: this.spec.ingressClassName,
      });
    }

    return out;
  }

  /**
   * The resources related to this Ingress, to edit by YAML alongside it
   *
   * Dependencies:
   * - the Services and resource backends it routes to, which are in its own namespace
   * - the Secrets named by `spec.tls`
   * - its IngressClass
   *
   * See https://kubernetes.io/docs/concepts/services-networking/ingress/
   *
   * @param {import('@shell/core/types').EditableRelatedResourcesFetchOptions} [options]
   * @returns {Promise<import('@shell/core/types').EditableRelatedResource[]>}
   */
  async fetchOwnEditableRelatedResources({ dependencies = true } = {}) {
    if (!this.metadata?.uid || !dependencies) {
      return [];
    }

    const namespace = this.metadata.namespace;
    const inNamespace = (name) => `${ namespace }/${ name }`;
    const serviceNames = [...new Set(ingressServiceNames(this))];
    const secretNames = [...new Set((this.spec?.tls || []).map((tls) => tls?.secretName).filter(Boolean))];
    const resourceBackends = ingressBackends(this).map((backend) => backend?.resource).filter((resource) => resource?.kind && resource?.name);

    const [services, secrets, backends, ingressClass] = await Promise.all([
      Promise.all(serviceNames.map((name) => findIfExists(this, SERVICE, inNamespace(name)))),
      Promise.all(secretNames.map((name) => findIfExists(this, SECRET, inNamespace(name)))),
      Promise.all(resourceBackends.map(({ apiGroup, kind, name }) => findIfExists(this, typeForKind(apiGroup, kind), inNamespace(name)))),
      findIfExists(this, INGRESS_CLASS, this.spec?.ingressClassName),
    ]);

    const classBanner = () => ({ color: 'warning', label: this.t('resourceYaml.resourceGraph.banners.sharedByIngresses') });

    return [
      ...services.filter(Boolean).map((resource) => relatedEntry(resource)),
      ...backends.filter(Boolean).map((resource) => relatedEntry(resource)),
      ...secrets.filter(Boolean).map((resource) => relatedEntry(resource)),
      ...(ingressClass ? [relatedEntry(ingressClass, { banner: classBanner })] : []),
    ];
  }
}
